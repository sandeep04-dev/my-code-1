"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Play, BookOpen } from "lucide-react"
import { useState } from "react"

const dsaVideos = [
  {
    id: 1,
    title: "Binary Search Algorithm Explained",
    description: "Complete guide to binary search with step-by-step implementation and analysis.",
    secondLine: "Covers iterative and recursive approaches with real-world examples and interview questions.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Beginner",
    topic: "Searching",
    color: "bg-blue-600",
  },
  {
    id: 2,
    title: "Dynamic Programming Fundamentals",
    description: "Master dynamic programming with classic problems like Fibonacci and Knapsack.",
    secondLine: "Learn memoization and tabulation techniques for coding interviews.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Intermediate",
    topic: "Dynamic Programming",
    color: "bg-purple-600",
  },
  {
    id: 3,
    title: "Graph Traversal: BFS vs DFS",
    description: "Deep dive into graph algorithms covering breadth-first and depth-first search.",
    secondLine: "Practical implementations with adjacency lists and solving real graph problems.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Intermediate",
    topic: "Graph Theory",
    color: "bg-cyan-600",
  },
  {
    id: 4,
    title: "Linked List Operations",
    description: "Complete tutorial on linked list operations including insertion and deletion.",
    secondLine: "Covers singly, doubly linked lists with pointer manipulation tricks.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Beginner",
    topic: "Data Structures",
    color: "bg-indigo-600",
  },
  {
    id: 5,
    title: "Tree Traversal Algorithms",
    description: "Master inorder, preorder, and postorder traversals with recursive methods.",
    secondLine: "Includes binary search trees and practical applications in interviews.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Intermediate",
    topic: "Trees",
    color: "bg-violet-600",
  },
  {
    id: 6,
    title: "Sorting Algorithms Comparison",
    description: "Comprehensive comparison of bubble sort, merge sort, and quick sort algorithms.",
    secondLine: "Analyze complexity with visual demonstrations and when to use each algorithm.",
    thumbnail: "/placeholder.svg?height=200&width=350",
    difficulty: "Advanced",
    topic: "Sorting",
    color: "bg-pink-600",
  },
]

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "Beginner":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30"
    case "Intermediate":
      return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
    case "Advanced":
      return "bg-red-500/20 text-red-400 border-red-500/30"
    default:
      return "bg-gray-500/20 text-gray-400 border-gray-500/30"
  }
}

export default function ContentSection() {
  const [clickedVideo, setClickedVideo] = useState<number | null>(null)

  const handleClick = (videoId: number) => {
    setClickedVideo(videoId)
    setTimeout(() => setClickedVideo(null), 300)
  }

  return (
    <section
      id="content"
      className="relative w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-gray-900 via-slate-800 to-gray-900 overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-16 w-1 h-1 bg-blue-400 rounded-full animate-pulse"></div>
        <div className="absolute top-60 right-32 w-2 h-2 bg-purple-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-32 left-1/3 w-1 h-1 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-pink-400 rounded-full animate-pulse"></div>
      </div>

      <div className="relative z-10 container max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BookOpen className="w-8 h-8 text-blue-400" />
            <h2 className="text-3xl md:text-4xl font-bold text-white">DSA Content Library</h2>
          </div>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Educational content on Data Structures and Algorithms to help students master coding interviews.
          </p>
        </div>

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {dsaVideos.map((video) => (
            <Card
              key={video.id}
              className={`group hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-300 transform ${
                clickedVideo === video.id ? "scale-95" : "hover:scale-105"
              } border-gray-700 bg-gray-800/80 backdrop-blur-sm shadow-lg overflow-hidden cursor-pointer`}
              onClick={() => handleClick(video.id)}
            >
              {/* Video Thumbnail */}
              <div className="relative overflow-hidden">
                <img
                  src={video.thumbnail || "/placeholder.svg"}
                  alt={`${video.title} thumbnail`}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button size="lg" className="rounded-full w-16 h-16 p-0 bg-blue-600 hover:bg-blue-700">
                    <Play className="w-6 h-6 ml-1" />
                  </Button>
                </div>
                <div
                  className={`absolute top-2 left-2 ${video.color} text-white px-2 py-1 rounded text-xs font-medium`}
                >
                  {video.topic}
                </div>
              </div>

              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-bold group-hover:text-blue-400 transition-colors line-clamp-2 text-white">
                  {video.title}
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="text-sm text-gray-300">
                  <p className="leading-relaxed">{video.description}</p>
                  <p className="leading-relaxed mt-2">{video.secondLine}</p>
                </div>

                {/* Difficulty Badge */}
                <div className="flex justify-between items-center">
                  <Badge className={getDifficultyColor(video.difficulty)}>{video.difficulty}</Badge>
                  <Button size="sm" variant="ghost" className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/20">
                    Watch Now →
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 p-8 bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-700">
          <h3 className="text-2xl font-bold mb-4 text-white">Want to Learn More?</h3>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Subscribe for regular DSA tutorials, coding interview tips, and programming content.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-blue-500/25"
            >
              Subscribe to Channel
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-8 border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white transform hover:scale-105 transition-all duration-300 bg-transparent"
            >
              View All Videos
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
