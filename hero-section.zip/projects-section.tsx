"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Globe, CheckSquare, Calendar } from "lucide-react"
import { useState } from "react"

const projects = [
  {
    id: 1,
    title: "Personal Portfolio Website",
    description:
      "A responsive portfolio website built with modern web technologies to showcase my skills and projects.",
    secondLine: "Features interactive animations, contact forms, and optimized performance for all devices.",
    technologies: ["HTML", "CSS", "JavaScript", "React"],
    icon: Globe,
    color: "bg-blue-600",
  },
  {
    id: 2,
    title: "Task Management App",
    description: "A full-featured todo application with user authentication and real-time task synchronization.",
    secondLine: "Includes drag-and-drop functionality, priority levels, and collaborative task sharing.",
    technologies: ["JavaScript", "Python", "CSS", "HTML"],
    icon: CheckSquare,
    color: "bg-purple-600",
  },
  {
    id: 3,
    title: "Weather Dashboard",
    description: "An interactive weather application that provides real-time weather data and forecasts.",
    secondLine: "Features location-based weather, forecasts, and beautiful weather animations and charts.",
    technologies: ["JavaScript", "HTML", "CSS", "Python"],
    icon: Calendar,
    color: "bg-cyan-600",
  },
]

export default function ProjectsSection() {
  const [clickedProject, setClickedProject] = useState<number | null>(null)

  const handleClick = (projectId: number) => {
    setClickedProject(projectId)
    setTimeout(() => setClickedProject(null), 300)
  }

  return (
    <section
      id="projects"
      className="relative w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-slate-900 via-gray-900 to-black overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-32 left-10 w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
        <div className="absolute top-20 right-20 w-1 h-1 bg-purple-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 left-1/4 w-1 h-1 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="absolute top-1/2 right-1/3 w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
      </div>

      <div className="relative z-10 container max-w-6xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">My Projects</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Here are some projects showcasing my skills in web development and programming.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => {
            const IconComponent = project.icon
            return (
              <Card
                key={project.id}
                className={`group hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-300 transform ${
                  clickedProject === project.id ? "scale-95" : "hover:scale-105"
                } border-gray-700 bg-gray-800/80 backdrop-blur-sm shadow-lg cursor-pointer`}
                onClick={() => handleClick(project.id)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-lg ${project.color} flex items-center justify-center shadow-lg`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-500/20 text-gray-400 hover:text-blue-400"
                      >
                        <Github className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-purple-500/20 text-gray-400 hover:text-purple-400"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold group-hover:text-blue-400 transition-colors text-white">
                    {project.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="text-gray-300">
                    <p className="leading-relaxed">{project.description}</p>
                    <p className="leading-relaxed mt-2">{project.secondLine}</p>
                  </div>

                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <Badge key={tech} className="bg-gray-700 text-gray-300 border-gray-600">
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3 pt-4">
                    <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Project
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 border-purple-600 text-purple-400 hover:bg-purple-600 hover:text-white bg-transparent"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p className="text-gray-400 mb-6">Want to see more of my work or collaborate on a project?</p>
          <Button
            size="lg"
            className="px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-blue-500/25"
          >
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  )
}
