import HeroSection from "../hero-section"
import AboutSection from "../about-section"
import ProjectsSection from "../projects-section"
import ContentSection from "../content-section"
import ContactSection from "../contact-section"

export default function Page() {
  return (
    <main>
      <HeroSection />
      <AboutSection />
      <ProjectsSection />
      <ContentSection />
      <ContactSection />
    </main>
  )
}
