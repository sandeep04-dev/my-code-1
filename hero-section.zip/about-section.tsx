"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Database, Globe, Palette } from "lucide-react"
import { useState } from "react"

const skills = [
  {
    name: "HTML",
    icon: Globe,
    color: "bg-blue-600",
    description: "Modern web markup and structure",
  },
  {
    name: "CSS",
    icon: Palette,
    color: "bg-purple-600",
    description: "Responsive design and animations",
  },
  {
    name: "JavaScript",
    icon: Code,
    color: "bg-cyan-600",
    description: "Interactive web applications",
  },
  {
    name: "Python",
    icon: Database,
    color: "bg-indigo-600",
    description: "Backend development and automation",
  },
]

export default function AboutSection() {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null)
  const [clickEffect, setClickEffect] = useState<string | null>(null)

  const handleClick = (skillName: string) => {
    setClickEffect(skillName)
    setTimeout(() => setClickEffect(null), 300)
  }

  return (
    <section
      id="about"
      className="relative w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-gray-900 via-slate-800 to-gray-900 overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-20 w-1 h-1 bg-blue-400 rounded-full animate-pulse"></div>
        <div className="absolute top-60 right-40 w-2 h-2 bg-purple-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 left-1/3 w-1 h-1 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="absolute top-1/4 right-1/4 w-1 h-1 bg-white rounded-full animate-pulse"></div>
      </div>

      <div className="relative z-10 container max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Profile Image and Info */}
          <div className="flex flex-col items-center lg:items-start space-y-6">
            <div className="relative group">
              <div className="w-64 h-64 rounded-full overflow-hidden border-4 border-blue-500/30 shadow-2xl shadow-blue-500/20 transform group-hover:scale-105 transition-all duration-500">
                <img
                  src="/images/profile-photo.png"
                  alt="AVANTSA VENKATA LAKSHMANA SAI SANDEEP"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
                <Code className="w-8 h-8 text-white" />
              </div>
            </div>

            <div className="text-center lg:text-left backdrop-blur-sm bg-black/20 p-6 rounded-2xl border border-white/10">
              <h2 className="text-3xl font-bold mb-4 text-white">About Me</h2>
              <p className="text-lg text-gray-300 leading-relaxed">
                I'm a passionate B.Tech student with a deep love for web development and technology. My journey in
                programming started with curiosity and has evolved into creating innovative digital solutions.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed mt-4">
                I enjoy tackling complex problems and turning ideas into reality through code. Always learning and
                staying updated with the latest tech trends.
              </p>
            </div>
          </div>

          {/* Skills Section */}
          <div className="space-y-8">
            <div className="text-center lg:text-left">
              <h3 className="text-2xl font-bold mb-2 text-white">My Skills</h3>
              <p className="text-gray-400">Technologies I work with to bring ideas to life</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {skills.map((skill) => {
                const IconComponent = skill.icon
                return (
                  <Card
                    key={skill.name}
                    className={`relative overflow-hidden transition-all duration-300 cursor-pointer transform ${
                      hoveredSkill === skill.name
                        ? "scale-105 shadow-2xl shadow-blue-500/20"
                        : "shadow-lg hover:scale-102"
                    } ${clickEffect === skill.name ? "scale-95" : ""} border-gray-700 bg-gray-800/80 backdrop-blur-sm`}
                    onMouseEnter={() => setHoveredSkill(skill.name)}
                    onMouseLeave={() => setHoveredSkill(null)}
                    onClick={() => handleClick(skill.name)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-12 h-12 rounded-lg ${skill.color} flex items-center justify-center shadow-lg`}
                        >
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h4 className="text-xl font-semibold text-white">{skill.name}</h4>
                          <p className="text-sm text-gray-400 mt-1">{skill.description}</p>
                        </div>
                      </div>

                      {/* Animated background */}
                      <div
                        className={`absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 opacity-0 transition-opacity duration-300 ${
                          hoveredSkill === skill.name ? "opacity-100" : ""
                        }`}
                      />
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Skill Tags */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
              <Badge className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-colors cursor-pointer border-blue-500/30">
                Problem Solving
              </Badge>
              <Badge className="bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 transition-colors cursor-pointer border-purple-500/30">
                Team Work
              </Badge>
              <Badge className="bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-colors cursor-pointer border-cyan-500/30">
                Creative Thinking
              </Badge>
              <Badge className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 transition-colors cursor-pointer border-indigo-500/30">
                Fast Learner
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
