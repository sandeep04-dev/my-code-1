"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Github, Linkedin, Mail, Send } from "lucide-react"
import { useState } from "react"

export default function ContactSection() {
  const [clickedElement, setClickedElement] = useState<string | null>(null)

  const handleClick = (element: string) => {
    setClickedElement(element)
    setTimeout(() => setClickedElement(null), 300)
  }

  return (
    <section
      id="contact"
      className="relative w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-black via-gray-900 to-slate-900 overflow-hidden"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-32 w-1 h-1 bg-purple-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 left-1/4 w-1 h-1 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="absolute top-1/2 right-1/3 w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
      </div>

      <div className="relative z-10 container max-w-6xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Get In Touch</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            I'm always open to discussing new opportunities and collaborations. Feel free to reach out!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="backdrop-blur-sm bg-black/20 p-6 rounded-2xl border border-white/10">
              <h3 className="text-2xl font-bold mb-6 text-white">Let's Connect</h3>
              <p className="text-gray-400 mb-8">
                Whether you're looking for a developer, have a project in mind, or want to discuss DSA concepts, I'd
                love to hear from you.
              </p>
            </div>

            {/* Social Links */}
            <div className="space-y-4">
              <a
                href="https://www.linkedin.com/in/sai-sandeep-0333722b7"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-4 p-4 rounded-lg border border-gray-700 bg-gray-800/80 backdrop-blur-sm hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300 group transform ${
                  clickedElement === "linkedin" ? "scale-95" : "hover:scale-105"
                }`}
                onClick={() => handleClick("linkedin")}
              >
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                  <Linkedin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold group-hover:text-blue-400 transition-colors text-white">LinkedIn</h4>
                  <p className="text-sm text-gray-400">Connect with me professionally</p>
                </div>
              </a>

              <a
                href="https://github.com/sandeep04-dev"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-4 p-4 rounded-lg border border-gray-700 bg-gray-800/80 backdrop-blur-sm hover:shadow-lg hover:shadow-purple-500/20 transition-all duration-300 group transform ${
                  clickedElement === "github" ? "scale-95" : "hover:scale-105"
                }`}
                onClick={() => handleClick("github")}
              >
                <div className="w-12 h-12 bg-gray-700 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                  <Github className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold group-hover:text-purple-400 transition-colors text-white">GitHub</h4>
                  <p className="text-sm text-gray-400">Check out my code and projects</p>
                </div>
              </a>

              <a
                href="mailto:avantsasaisandeep@gmail.com"
                className="flex items-center gap-4 p-4 rounded-lg border border-gray-700 bg-gray-800/80 backdrop-blur-sm hover:shadow-lg hover:shadow-cyan-500/20 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-cyan-600 rounded-lg flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-white group-hover:text-cyan-400 transition-colors">Email</h4>
                  <p className="text-sm text-gray-400">avantsasaisandeep@gmail.com</p>
                </div>
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="shadow-lg border-gray-700 bg-gray-800/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-white">Send a Message</CardTitle>
              <p className="text-gray-400">Fill out the form below and I'll get back to you soon.</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="firstName" className="text-sm font-medium text-gray-300">
                    First Name
                  </label>
                  <Input
                    id="firstName"
                    placeholder="Your first name"
                    className="border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="lastName" className="text-sm font-medium text-gray-300">
                    Last Name
                  </label>
                  <Input
                    id="lastName"
                    placeholder="Your last name"
                    className="border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-gray-300">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  className="border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="subject" className="text-sm font-medium text-gray-300">
                  Subject
                </label>
                <Input
                  id="subject"
                  placeholder="What's this about?"
                  className="border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-gray-300">
                  Message
                </label>
                <Textarea
                  id="message"
                  placeholder="Tell me about your project or just say hello!"
                  className="min-h-[120px] border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-500"
                />
              </div>

              <Button
                className={`w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform transition-all duration-300 ${
                  clickedElement === "send" ? "scale-95" : "hover:scale-105"
                } shadow-lg hover:shadow-blue-500/25`}
                size="lg"
                onClick={() => handleClick("send")}
              >
                <Send className="w-4 h-4 mr-2" />
                Send Message
              </Button>

              <p className="text-xs text-gray-500 text-center">
                I'll respond within 24 hours. Looking forward to hearing from you!
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 p-8 bg-gradient-to-r from-gray-800/50 to-slate-800/50 rounded-2xl border border-gray-700 backdrop-blur-sm">
          <h3 className="text-2xl font-bold mb-4 text-white">Ready to Work Together?</h3>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            I'm currently available for freelance projects, internships, and full-time opportunities. Let's build
            something amazing together!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className={`px-8 bg-blue-600 hover:bg-blue-700 transform transition-all duration-300 ${
                clickedElement === "connect" ? "scale-95" : "hover:scale-105"
              } shadow-lg hover:shadow-blue-500/25`}
              onClick={() => handleClick("connect")}
              asChild
            >
              <a href="https://www.linkedin.com/in/sai-sandeep-0333722b7" target="_blank" rel="noopener noreferrer">
                <Linkedin className="w-4 h-4 mr-2" />
                Connect on LinkedIn
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className={`px-8 border-purple-600 text-purple-400 hover:bg-purple-600 hover:text-white transform transition-all duration-300 ${
                clickedElement === "code" ? "scale-95" : "hover:scale-105"
              } bg-transparent`}
              onClick={() => handleClick("code")}
              asChild
            >
              <a href="https://github.com/sandeep04-dev" target="_blank" rel="noopener noreferrer">
                <Github className="w-4 h-4 mr-2" />
                View My Code
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
