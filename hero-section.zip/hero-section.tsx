"use client"

import { Button } from "@/components/ui/button"
import { Github, Linkedin, Mail, Home, User, FolderOpen, BookOpen, MessageCircle } from "lucide-react"
import { useState, useEffect } from "react"

// Space animation component
function SpaceBackground() {
  useEffect(() => {
    const createStar = () => {
      const star = document.createElement("div")
      star.className = "star"
      star.style.left = Math.random() * 100 + "%"
      star.style.animationDuration = Math.random() * 3 + 2 + "s"
      star.style.opacity = Math.random().toString()
      document.querySelector(".space-container")?.appendChild(star)

      setTimeout(() => {
        star.remove()
      }, 5000)
    }

    const interval = setInterval(createStar, 100)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-container absolute inset-0 overflow-hidden">
      <style jsx>{`
        .star {
          position: absolute;
          width: 2px;
          height: 2px;
          background: white;
          border-radius: 50%;
          animation: fall linear infinite;
        }
        
        .star:nth-child(odd) {
          background: #60a5fa;
          width: 1px;
          height: 1px;
        }
        
        .star:nth-child(3n) {
          background: #a78bfa;
          width: 3px;
          height: 3px;
        }
        
        @keyframes fall {
          0% {
            transform: translateY(-100vh) rotate(0deg);
          }
          100% {
            transform: translateY(100vh) rotate(360deg);
          }
        }
        
        .space-container::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: 
            radial-gradient(2px 2px at 20px 30px, #eee, transparent),
            radial-gradient(2px 2px at 40px 70px, rgba(255,255,255,0.8), transparent),
            radial-gradient(1px 1px at 90px 40px, #fff, transparent),
            radial-gradient(1px 1px at 130px 80px, rgba(255,255,255,0.6), transparent),
            radial-gradient(2px 2px at 160px 30px, #ddd, transparent);
          background-repeat: repeat;
          background-size: 200px 100px;
          animation: sparkle 3s linear infinite;
        }
        
        @keyframes sparkle {
          from { transform: translateX(0); }
          to { transform: translateX(-200px); }
        }
      `}</style>
    </div>
  )
}

// Navigation component
function FloatingNavigation() {
  const navItems = [
    { icon: Home, label: "Home", href: "#home" },
    { icon: User, label: "About", href: "#about" },
    { icon: FolderOpen, label: "Projects", href: "#projects" },
    { icon: BookOpen, label: "Content", href: "#content" },
    { icon: MessageCircle, label: "Contact", href: "#contact" },
  ]

  const scrollToSection = (href: string) => {
    if (href === "#home") {
      window.scrollTo({ top: 0, behavior: "smooth" })
    } else {
      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50">
      <div className="flex flex-col gap-4 backdrop-blur-sm bg-black/20 p-4 rounded-2xl border border-white/10">
        {navItems.map((item) => {
          const IconComponent = item.icon
          return (
            <Button
              key={item.label}
              size="icon"
              variant="ghost"
              className="h-12 w-12 hover:bg-blue-500/20 hover:scale-110 transition-all duration-300 text-gray-300 hover:text-blue-400 group relative"
              onClick={() => scrollToSection(item.href)}
            >
              <IconComponent className="h-5 w-5" />
              <span className="absolute right-full mr-3 px-2 py-1 bg-black/80 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                {item.label}
              </span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}

const keywords = [
  "Web Developer",
  "Content Creator",
  "Problem Solver",
  "Tech Enthusiast",
  "Code Artist",
  "Digital Innovator",
]

export default function Component() {
  const [clicked, setClicked] = useState(false)

  const handleClick = () => {
    setClicked(true)
    setTimeout(() => setClicked(false), 300)
  }

  const [currentKeywordIndex, setCurrentKeywordIndex] = useState(0)
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const currentKeyword = keywords[currentKeywordIndex]
    const words = currentKeyword.split(" ")

    const timer = setTimeout(
      () => {
        if (!isDeleting) {
          if (currentWordIndex < words.length) {
            setDisplayText(words.slice(0, currentWordIndex + 1).join(" "))
            setCurrentWordIndex((prev) => prev + 1)
          } else {
            setTimeout(() => setIsDeleting(true), 2000)
          }
        } else {
          if (currentWordIndex > 0) {
            setCurrentWordIndex((prev) => prev - 1)
            setDisplayText(words.slice(0, currentWordIndex - 1).join(" "))
          } else {
            setIsDeleting(false)
            setCurrentKeywordIndex((prev) => (prev + 1) % keywords.length)
          }
        }
      },
      isDeleting ? 100 : 500,
    )

    return () => clearTimeout(timer)
  }, [currentKeywordIndex, currentWordIndex, isDeleting])

  return (
    <section
      id="home"
      className="relative w-full min-h-screen flex items-center justify-center px-4 py-12 md:py-24 lg:py-32 bg-gradient-to-br from-gray-900 via-blue-900 to-black overflow-hidden"
    >
      {/* Space Background */}
      <SpaceBackground />

      {/* Floating Navigation */}
      <FloatingNavigation />

      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-20 w-1 h-1 bg-purple-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-32 left-1/4 w-3 h-3 bg-cyan-400 rounded-full animate-bounce"></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-white rounded-full animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-2 h-2 bg-indigo-400 rounded-full animate-ping"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container max-w-4xl mx-auto">
        <div className="flex flex-col items-center gap-6 text-center">
          {/* Name and Email Info Card */}
          <div className="backdrop-blur-sm bg-black/20 p-6 rounded-2xl border border-white/10 mb-4">
            <div className="flex items-center justify-center gap-3 mb-2">
              <User className="w-5 h-5 text-blue-400" />
              <span className="text-white font-medium">AVANTSA VENKATA LAKSHMANA SAI SANDEEP</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <Mail className="w-4 h-4 text-purple-400" />
              <a
                href="mailto:avantsasaisandeep@gmail.com"
                className="text-gray-300 hover:text-purple-400 transition-colors text-sm"
              >
                avantsasaisandeep@gmail.com
              </a>
            </div>
          </div>

          <div className="space-y-4 backdrop-blur-sm bg-black/20 p-8 rounded-3xl border border-white/10">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl text-white">
              Hi, I'm{" "}
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                AVANTSA VENKATA LAKSHMANA SAI SANDEEP
              </span>{" "}
              👋
            </h1>
            <p className="mx-auto max-w-[700px] text-xl text-gray-300 md:text-2xl">
              I'm a <span className="font-semibold text-blue-400">B.Tech Student</span> and{" "}
              <span className="font-semibold text-purple-400 min-h-[1.5em] inline-block">
                {displayText}
                <span className="animate-pulse">|</span>
              </span>
            </p>
            <p className="mx-auto max-w-[600px] text-gray-400 md:text-lg">
              Passionate about creating innovative web solutions and constantly learning new technologies.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <Button
              size="lg"
              className={`text-lg px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform transition-all duration-300 ${
                clicked ? "scale-95" : "hover:scale-105"
              } shadow-lg hover:shadow-blue-500/25`}
              onClick={() => {
                handleClick()
                document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              View My Work
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 border-blue-400 text-blue-400 hover:bg-blue-600 hover:text-white transform hover:scale-105 transition-all duration-300 bg-transparent hover:shadow-lg hover:shadow-blue-500/25"
              onClick={() => {
                handleClick()
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              Get In Touch
            </Button>
          </div>

          <div className="flex items-center gap-6 mt-8">
            <Button
              size="icon"
              variant="ghost"
              className="h-12 w-12 hover:bg-blue-500/20 hover:scale-110 transition-all duration-300 text-gray-300 hover:text-blue-400"
              asChild
              onClick={handleClick}
            >
              <a href="https://github.com/sandeep04-dev" target="_blank" rel="noopener noreferrer">
                <Github className="h-6 w-6" />
                <span className="sr-only">GitHub</span>
              </a>
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="h-12 w-12 hover:bg-purple-500/20 hover:scale-110 transition-all duration-300 text-gray-300 hover:text-purple-400"
              asChild
              onClick={handleClick}
            >
              <a href="https://www.linkedin.com/in/sai-sandeep-0333722b7" target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-6 w-6" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="h-12 w-12 hover:bg-cyan-500/20 hover:scale-110 transition-all duration-300 text-gray-300 hover:text-cyan-400"
              asChild
              onClick={handleClick}
            >
              <a href="mailto:avantsasaisandeep@gmail.com">
                <Mail className="h-6 w-6" />
                <span className="sr-only">Email</span>
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
